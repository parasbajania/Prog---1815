﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp7
{
    public class Employee : Form1
    {
       public string name;
       public int hours_worked;
       public double salary;
       public  double sale_hr;

        public Employee()
            {
            hours_worked = 0;
            salary = 0;
            name = "no name";
            }
        public void Validator()
        {
           
        }
       public double calculateSalary(int hours_worked,double salperhr)
        {
            salary = hours_worked * salperhr;
            return salary;
  
        }

    }
   
    }
