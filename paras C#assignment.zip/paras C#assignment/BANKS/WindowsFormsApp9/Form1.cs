﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
   
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex==1)
            {
                
                IBANK Qs = new SBI();
                double sbi = Qs.getRateOfInterest();
                label3.Text = sbi.ToString();
            }
           if (listBox1.SelectedIndex == 2)
            {
                IBANK Wi = new ICICI();
               double icici =  Wi.getRateOfInterest();
                label3.Text = icici.ToString();
            }
            if (listBox1.SelectedIndex == 3)
            {
                IBANK Ea = new AXIS();
                double axis = Ea.getRateOfInterest();
                label3.Text = axis.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
