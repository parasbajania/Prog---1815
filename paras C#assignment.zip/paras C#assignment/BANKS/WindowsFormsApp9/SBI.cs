﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp9
{
     class SBI : IBANK
    {
        
         double IBANK.getRateOfInterest()

        {
            double rate = 8;
            return rate;
        }
    }
}
