﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp9
{
    class Bank
    {
        SBI ab = new SBI();
       // double sr = double.Parse(ab.getRateofInterest());
    }
    public interface IBANK
    {

        double getRateOfInterest();
        
      



    }

}
