﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8
{
    class Cube : Circle

    {
        public double Circumferencec(double side)
        {
            double circumference = 12 * side;
            return circumference;
        }
        public double Areac(double side)
        {
            double area = 6*side * side;
            return area;
        }
        public double Volumec(double side)
        {
            double volume = side * side * side;
            return volume;
        }
    }
}
