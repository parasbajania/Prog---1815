﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
   class driver : Circle 
    {
        double circumference , area ,volume;
        public void Rectangle()
        {
            Rectangle rc = new Rectangle();
            circumference = rc.Circumference(length, breadth, height);
            

            Rectangle ra = new Rectangle();
            area = ra.Area(length, breadth, height);

            Rectangle rv = new Rectangle();
            volume = rv.Volume(length, breadth, height);

            MessageBox.Show("Circumference of rectangle is " + circumference +"\n"+
"Area is " + area + "\n" +" Volume is " + volume);


        }
        public void Cube()
        {
            Cube cc = new Cube();
            circumference = cc.Circumferencec(length);

            Cube ca = new Cube();
            area = ca.Areac(length);

            Cube cv = new Cube();
            volume = cv.Volumec(length);

            MessageBox.Show("Circumference of Cube is " + circumference + "\n" +
"Area is " + area + "\n" + " Volume is " + volume);
        }

        public void Circle()
        {

            Circle crc = new Circle();
            circumference = crc.Circumference(length);

            Circle cra = new Circle();
            area = cra.Area(length);

            Circle crv = new Circle();
            volume = crv.Volume(length);

            MessageBox.Show("Circumference of Circle is " + circumference + "\n" +
"Area is " + area + "\n" + " Volume is " + volume);
        }
    }
}
