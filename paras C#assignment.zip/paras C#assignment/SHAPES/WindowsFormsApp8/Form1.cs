﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

           
        }

        
        public void Result()
        {
       

            driver c = new driver();
        c.Rectangle();

            driver a = new driver();
        a.Cube();

            driver v = new driver();
        v.Circle();
            }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            a.Result();
        }
    }
}
