﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8
{
    class Circle : Rectangle
    {
        public double Circumference(double radius)
        {
            double circumference = 2 * 3.14 * radius;
            return circumference;
        }
        public double Area(double radius)
        {
            double area = 3.14 * radius * radius;
            return area;
        }
        public double Volume(double radius)
        {
            double volume = 4 / 3 * (3.14 * radius * radius * radius);
            return volume;
        }
    }
}
