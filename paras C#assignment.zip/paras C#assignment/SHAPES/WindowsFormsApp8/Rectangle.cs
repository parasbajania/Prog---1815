﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8
{
    class Rectangle
        
    {
        public double length = 2, breadth = 3, height =4;
        public double Circumference(double length ,double breadth,double height)
        {
            double circumference = 4*(length + breadth+height);
                return circumference;
        }
        public double Area(double length, double breadth,double height)
        {
            double area = 2*(length*breadth+length*height+breadth*height);
            return area;
        }
        public double Volume(double length, double breadth, double height)
        {
            double volume = length * breadth * height;
            return volume;

        }
    }
}
